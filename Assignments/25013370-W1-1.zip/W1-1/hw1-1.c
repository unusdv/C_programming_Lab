#include <stdio.h>

int main (void){
    printf("I Asilbek think that C Programming is high level language.");
    return 0;
}