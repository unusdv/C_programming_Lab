#include <stdio.h>

int main(void)
{
    printf("I threw a boomerang ");
    printf("a few years ago. \n");
    printf("   -I now live in fear. \n");

    return 0;
}