#include <stdio.h>

int main(void){

    int Population = 37456235;
    float MaxTemperature = 45.3;

    printf("Uzbekistan has a population of %d, and it gets up to %.2f C during the summer. ", Population, MaxTemperature);

    return 0;
}